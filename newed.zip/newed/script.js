function checkPassword() {
    let password = document.getElementById('password').value;

    if (password === "") {
        window.location.href = "limbo.html";
    } else if (password === "limbo") {
        window.location.href = "arrows.html"
    } else if (Math.floor(Math.random() * 4) < 1 && localStorage.getItem('wasInHall') == 'true' && localStorage.getItem('bell1') == null){
        window.location.href = "vestebul.html";
    } else{
        window.location.href = "mainhall.html";
    }
}

let pressedKeys = []; // Массив для хранения нажатых клавиш

document.addEventListener('keydown', function (event) {
    pressedKeys.push(event.key); // Добавляем нажатую клавишу в массив

    if (pressedKeys.length > 4) { // Если длина массива превысила 4,  удаляем  первый  элемент
        pressedKeys.shift();
    }

    if (pressedKeys.join('') === "7789" && document.getElementById("password").value === "") {
        console.log("Ты нажал 7789!");
        const backVon = document.getElementById("bacVon")
        backVon.style.backgroundColor = "black";
    }
});
let welocometext = document.getElementById('welocometext')
if (localStorage.getItem("throne") == 'true'){
    welocometext.innerHTML='Добро пожаловать <br> Король!';
};
