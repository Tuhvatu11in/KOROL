const audioMap = {
    '1': new Audio('bells/bell_A2.mp3'),
    '2': new Audio('bells/bell_A.mp3'),
    '3': new Audio('bells/bell_B.mp3'),
    '4': new Audio('bells/bell_C.mp3'),
    '6': new Audio('bells/bell_D.mp3'),
    '7': new Audio('bells/bell_E.mp3'),
    '8': new Audio('bells/bell_F.mp3'),
    '9': new Audio('bells/bell_G.mp3'),
};

document.addEventListener('keydown', (event) => {
    const key = event.key;
    console.log(key, 'bell${key}')
    if (key >= '1' && key <= '9') {
        audioMap[key].play();
        audioMap[key].currentTime = 0
    }
});
